package com.brokesmpv1.commands;

import com.brokesmpv1.BrokeSMPV1;
import com.brokesmpv1.shards.ShardType;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class ShardCommand implements CommandExecutor {
    private final BrokeSMPV1 plugin;
    public ShardCommand(BrokeSMPV1 plugin){ this.plugin = plugin; }
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("brokesmp.admin")){ sender.sendMessage("§cNo permission."); return true; }
        if (args.length < 3 || !args[0].equalsIgnoreCase("give")){
            sender.sendMessage("§e/shard give <player> <type> [tier]");
            sender.sendMessage("§7Types: " + String.join(", ", ShardType.names()));
            return true;
        }
        Player t = Bukkit.getPlayerExact(args[1]);
        if (t == null){ sender.sendMessage("§cPlayer not found."); return true; }
        ShardType type;
        try { type = ShardType.valueOf(args[2].toUpperCase()); } catch (Exception e){ sender.sendMessage("§cInvalid type."); return true; }
        int tier = 1;
        if (args.length >= 4) try { tier = Math.max(1, Math.min(3, Integer.parseInt(args[3]))); } catch (Exception ignored){}
        plugin.shards().giveShard(t, type, tier);
        sender.sendMessage("§aGave §e" + type.getDisplayName() + " §7(Tier " + tier + ") to §e" + t.getName());
        return true;
    }
}
