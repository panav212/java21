package com.brokesmpv1.commands;

import com.brokesmpv1.BrokeSMPV1;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class LifeCommand implements CommandExecutor {
    private final BrokeSMPV1 plugin;
    public LifeCommand(BrokeSMPV1 plugin){ this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("brokesmp.admin")) { sender.sendMessage("§cNo permission."); return true; }
        if (args.length != 3){ sender.sendMessage("§e/life <add|remove|set> <player> <amount>"); return true; }
        Player t = Bukkit.getPlayerExact(args[1]);
        if (t == null){ sender.sendMessage("§cPlayer not found."); return true; }
        int amt;
        try { amt = Integer.parseInt(args[2]); } catch (Exception ex){ sender.sendMessage("§cInvalid amount."); return true; }
        switch (args[0].toLowerCase()){
            case "add" -> plugin.lives().addLives(t, amt);
            case "remove" -> plugin.lives().removeLives(t, amt);
            case "set" -> plugin.lives().setLives(t, amt);
            default -> sender.sendMessage("§e/life <add|remove|set> <player> <amount>");
        }
        sender.sendMessage("§aLives updated for §e" + t.getName());
        return true;
    }
}
