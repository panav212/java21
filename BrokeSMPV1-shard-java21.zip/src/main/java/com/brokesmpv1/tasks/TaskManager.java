package com.brokesmpv1.tasks;

import com.brokesmpv1.BrokeSMPV1;
import org.bukkit.*;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import java.util.*;

public class TaskManager implements Listener {
    private final BrokeSMPV1 plugin;
    private final Map<UUID, List<Task>> tasks = new HashMap<>();
    private final Map<UUID, Location> lastLoc = new HashMap<>();

    public TaskManager(BrokeSMPV1 plugin){ this.plugin = plugin; }

    public List<Task> getTasks(UUID uuid){
        return tasks.computeIfAbsent(uuid, x -> generateDefaultTasks());
    }

    public void claim(UUID uuid, Task t){
        Player p = Bukkit.getPlayer(uuid);
        if (p == null) return;
        plugin.economy().addCoins(p, t.reward());
        t.setClaimed(true);
    }

    private List<Task> generateDefaultTasks(){
        List<Task> list = new ArrayList<>();
        list.add(Task.kill("Monster Hunter", "Kill 5 Zombies", EntityType.ZOMBIE, 5, 100));
        list.add(Task.kill("Skelly Buster", "Kill 5 Skeletons", EntityType.SKELETON, 5, 120));
        list.add(Task.mine("Acquire Hardware", "Mine 20 Iron Ore", Material.IRON_ORE, 20, 150));
        list.add(Task.mine("Shiny!", "Mine 10 Diamonds", Material.DIAMOND_ORE, 10, 300));
        list.add(Task.fish("Angler", "Catch 5 fish", 5, 80));
        list.add(Task.travel("Explorer", "Travel 1000 blocks", 1000, 120));
        list.add(Task.adv("Advancement: Stone Age", "minecraft:story/stone_age", 150));
        list.add(Task.adv("Advancement: Iron Tools", "minecraft:story/iron_tools", 200));
        list.add(Task.adv("Advancement: Diamonds!", "minecraft:story/mine_diamond", 300));
        list.add(Task.adv("Advancement: End?", "minecraft:end/root", 400));
        return list;
    }

    @EventHandler public void onJoin(PlayerJoinEvent e){ getTasks(e.getPlayer().getUniqueId()); lastLoc.put(e.getPlayer().getUniqueId(), e.getPlayer().getLocation()); }

    @EventHandler public void onKill(EntityDeathEvent e){
        if (!(e.getEntity().getKiller() instanceof Player p)) return;
        for (Task t : getTasks(p.getUniqueId())){
            t.onKill(p, e.getEntityType());
            t.onAdvancement(p);
        }
    }

    @EventHandler public void onBreak(BlockBreakEvent e){
        Player p = e.getPlayer();
        for (Task t : getTasks(p.getUniqueId())) t.onMine(p, e.getBlock().getType());
    }

    @EventHandler public void onFish(PlayerFishEvent e){
        if (!(e.getState() == PlayerFishEvent.State.CAUGHT_FISH)) return;
        Player p = e.getPlayer();
        for (Task t : getTasks(p.getUniqueId())) t.onFish(p);
    }

    @EventHandler public void onMove(PlayerMoveEvent e){
        Player p = e.getPlayer();
        Location prev = lastLoc.getOrDefault(p.getUniqueId(), e.getFrom());
        double dist = prev.distance(e.getTo());
        if (dist >= 1){
            for (Task t : getTasks(p.getUniqueId())) t.onTravel(p, (int) Math.round(dist));
            lastLoc.put(p.getUniqueId(), e.getTo());
        }
    }
}
